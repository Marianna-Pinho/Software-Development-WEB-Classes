//package br.com.ufc.repository;
//
//import org.springframework.data.jpa.repository.JpaRepository;
//
//import br.com.ufc.model.Usuario;
//
//public interface PedidoRepository extends JpaRepository<T, ID> {
//
//}

package br.com.ufc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TrabalhoFinalBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(TrabalhoFinalBackendApplication.class, args);
	}

}
